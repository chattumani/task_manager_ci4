<?php

namespace App\Controllers;

use App\Models\TaskModel;

class TaskController extends BaseController
{
    public function index()
    {
		
        $taskModel = new TaskModel();
        $data['tasks'] = $taskModel->paginate(10); // 10 rows per page
        // Get the pager instance
        $data['pager'] = $taskModel->pager;
        return view('task_list', $data);
    }
	
	
	
	
   
	
	public function details($taskId)
    {
        $taskModel = new TaskModel();
        $data['task'] = $taskModel->find($taskId);

        if ($data['task'] === null) {
            // Handle the case where the task with the given ID does not exist
            return redirect()->to('/task')->with('error', 'Task not found');
        }

        return view('task_details', $data);
    }
	
	public function create()
{
    return view('create_task');
}

public function edit($taskId)
{
    $taskModel = new TaskModel();
    $data['task'] = $taskModel->find($taskId);

    return view('edit_task', $data);
}

public function store()
{
    // Validate form input (assuming you're using CodeIgniter's validation)
    $validationRules = [
        'title' => 'required|min_length[3]|max_length[255]',
        'description' => 'required',
        'due_date' => 'required|valid_date',
    ];

    if (!$this->validate($validationRules)) {
        // If validation fails, redirect back to the create task page with validation errors
        return redirect()->to('/tasks/create')->withInput()->with('validation', $this->validator);
    }

    // If validation passes, insert the new task into the database
    $taskModel = new TaskModel();

    $data = [
        'title' => $this->request->getPost('title'),
        'description' => $this->request->getPost('description'),
        'due_date' => $this->request->getPost('due_date'),
        'status' => 'pending', // Set default status
    ];

    $taskModel->insert($data);

    // Redirect the user to the task list page
    return redirect()->to('/tasks')->with('success', 'Task created successfully');
}

// Task update method
public function update($taskId)
{
    // Validate form input (assuming you're using CodeIgniter's validation)
    $validationRules = [
        'title' => 'required|min_length[3]|max_length[255]',
        'description' => 'required',
        'due_date' => 'required|valid_date',
    ];

    if (!$this->validate($validationRules)) {
        // If validation fails, redirect back to the edit task page with validation errors
        return redirect()->to("/tasks/edit/$taskId")->withInput()->with('validation', $this->validator);
    }

    // If validation passes, update the existing task in the database
    $taskModel = new TaskModel();

    $data = [
        'title' => $this->request->getPost('title'),
        'description' => $this->request->getPost('description'),
        'due_date' => $this->request->getPost('due_date'),
		'status' => $this->request->getPost('status'),
    ];

    $taskModel->update($taskId, $data);

    // Redirect the user to the task list page
    return redirect()->to('/tasks')->with('success', 'Task updated successfully');
}

// Task deletion method
public function delete($taskId)
{
    // Delete the task from the database
    $taskModel = new TaskModel();
    $taskModel->delete($taskId);

    // Redirect the user to the task list page
    return redirect()->to('/tasks')->with('success', 'Task deleted successfully');
}

// Task status update method
public function changeStatus($taskId)
{
    // Update the status of the task in the database
    $taskModel = new TaskModel();
    $taskModel->update($taskId, ['status' => 'completed']);

    // Redirect the user to the task list page
    return redirect()->to('/tasks')->with('success', 'Task status updated successfully');
}


}
