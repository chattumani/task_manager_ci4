<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
	public function __construct()
    {
        helper('form'); // Load form helper
    }
	
	public function registerAdmin()
{
    $userModel = new UserModel();

    if ($this->request->getMethod() === 'post') {
        // Validation rules
        $rules = [
            'name' => 'required',
            'email' => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]'
        ];

        if (!$this->validate($rules)) {
            return view('register_admin', ['validation' => $this->validator]);
        } else {
            $password = $this->request->getVar('password');
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Save user with admin role
            $userModel->save([
                'name' => $this->request->getVar('name'),
                'email' => $this->request->getVar('email'),
                'password' => $hashedPassword,
                'role' => 'admin'
            ]);

            return redirect()->to('login');
        }
    }

    return view('register_admin');
}

	
	
    public function register()
    {
        $userModel = new UserModel();

        // If the form is submitted
        if ($this->request->getMethod() === 'post') {
            // Validation rules for registration form fields
            $rules = [
                'name' => 'required',
                'email' => 'required|valid_email|is_unique[users.email]',
                'password' => 'required|min_length[6]'
            ];

            // Validate form input
            if (!$this->validate($rules)) {
                // If validation fails, display registration form with errors
                return view('register', ['validation' => $this->validator]);
            } else {
                // Hash the password
                $password = $this->request->getVar('password');
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                // Save user to database
                $userModel->save([
                    'name' => $this->request->getVar('name'),
                    'email' => $this->request->getVar('email'),
                    'password' => $hashedPassword
                ]);

                // Redirect to login page
                return redirect()->to('login');
            }
        }

        // If the form is not submitted, display registration form
        return view('register');
    }

    public function login()
    {
        // If the form is submitted
        if ($this->request->getMethod() === 'post') {
            $email = $this->request->getVar('email');
            $password = $this->request->getVar('password');

            // Load user by email from database
            $userModel = new UserModel();
            $user = $userModel->where('email', $email)->first();

            // If user exists and password is correct
            if ($user && password_verify($password, $user['password'])) {
                // Set session data
                $session = session();
                $session->set([
                    'user_id' => $user['id'],
                    'user_email' => $user['email'],
                    'user_role' => $user['role'],
					'user_name' => $user['name']
                ]);

                 
                    return redirect()->to('tasks');
                
            } else {
                // If login fails, display login form with error message
                return view('login', ['error' => 'Invalid email or password']);
            }
        }

        // If the form is not submitted, display login form
        return view('login');
    }

    public function logout()
    {
        // Destroy user session
        $session = session();
        $session->destroy();

        // Redirect to login page
        return redirect()->to('login');
    }
}
