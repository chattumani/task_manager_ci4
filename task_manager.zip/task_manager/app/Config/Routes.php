<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'HomeController::index');

// Task routes
$routes->get('tasks', 'TaskController::index');
$routes->get('tasks/details/(:num)', 'TaskController::details/$1');
$routes->get('tasks/create', 'TaskController::create');
$routes->post('tasks/store', 'TaskController::store');
$routes->get('tasks/edit/(:num)', 'TaskController::edit/$1');
$routes->post('tasks/update/(:num)', 'TaskController::update/$1');
$routes->get('tasks/delete/(:num)', 'TaskController::delete/$1');
$routes->post('tasks/change-status/(:num)', 'TaskController::changeStatus/$1');


// app/Config/Routes.php

$routes->get('register', 'Auth::register');
$routes->post('register', 'Auth::register');
$routes->get('login', 'Auth::login');
$routes->post('login', 'Auth::login');
$routes->post('register/admin', 'Auth::registerAdmin');
$routes->get('logout', 'Auth::logout');
$routes->get('register/admin', 'Auth::registerAdmin');

