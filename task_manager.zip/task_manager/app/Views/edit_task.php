<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Custom CSS -->
    <link rel="stylesheet" href="/css/styles.css">
    <title>Edit Task</title>
</head>
<body>
    <div class="container">
        <h1>Edit Task</h1>

        <form action="<?= base_url('tasks/update/'.$task['id']) ?>" method="post">
            <div class="mb-3">
                <label for="title" class="form-label">Title:</label>
                <input type="text" class="form-control" id="title" name="title" value="<?= $task['title'] ?>">
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description:</label>
                <textarea class="form-control" id="description" name="description"><?= $task['description'] ?></textarea>
            </div>

            <div class="mb-3">
                <label for="due_date" class="form-label">Due Date:</label>
                <input type="date" class="form-control" id="due_date" name="due_date" value="<?= $task['due_date'] ?>">
            </div>

            <div class="mb-3">
                <label for="status" class="form-label">Status:</label>
                <select class="form-select" id="status" name="status">
                    <option value="pending" <?= ($task['status'] == 'pending') ? 'selected' : '' ?>>Pending</option>
                    <option value="completed" <?= ($task['status'] == 'completed') ? 'selected' : '' ?>>Completed</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Update Task</button>
        </form>

        <a href="<?= base_url('tasks') ?>" class="btn btn-secondary mt-3">Back to Task List</a>
    </div>
</body>
</html>
