<!-- app/Views/dashboard.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5 text-center">
        <h1 class="mb-4">Simple Task Management System Requirements</h1>
        
        <?php if(!session()->get('isLoggedIn')): ?>
            <a href="<?= base_url('register') ?>" class="btn btn-primary mb-3">User Registration</a>
            <a href="<?= base_url('login') ?>" class="btn btn-success mb-3">Login</a>
        <a href="<?= base_url('register/admin') ?>" class="btn btn-warning mb-3">Admin Registration</a>
		<?php endif; ?>
		<div>
        <h2>Magnet Brains - India's Number 1 Online School Education Platform</h2>
        <p>Which provides high quality education</p>
    </div>
    </div>

    <!-- Bootstrap JS (optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gW6c/9i9K3awr73b2nq8w3uEKDhmEjwsYS2gdSUuVXE1AplCqP+30JoPJFhRqtJf" crossorigin="anonymous"></script>
</body>
</html>
