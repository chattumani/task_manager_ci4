<!-- app/Views/task_list.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task List</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Custom CSS -->
    <link rel="stylesheet" href="/css/styles.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Task List</h1>
 <!-- Display user name -->
        <p>Welcome, <?= session()->get('user_name') ?></p>
        <a href="<?= base_url('tasks/create') ?>" class="btn btn-primary mb-3">Create New Task</a>

        <table class="table table-dark">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Due Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tasks as $task): ?>
                <tr>
                    <td><?= $task['title'] ?></td>
                    <td><?= $task['description'] ?></td>
                    <td><?= $task['due_date'] ?></td>
                    <td><?= $task['status'] ?></td>
                   <td>
    <button type="button" class="btn btn-info btn-sm">
        <a href="<?= base_url('tasks/details/' . $task['id']) ?>" style="color: white; text-decoration: none;">View</a>
    </button>
    <button type="button" class="btn btn-warning btn-sm">
        <a href="<?= base_url('tasks/edit/' . $task['id']) ?>" style="color: white; text-decoration: none;">Edit</a>
    </button>
    <?php if(session()->get('user_role') === 'admin'): ?>
    <button type="button" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this task?')">
        <a href="<?= base_url('tasks/delete/' . $task['id']) ?>" style="color: white; text-decoration: none;">Delete</a>
    </button>
<?php endif; ?>
</td>

                </tr>
                <?php endforeach; ?>
            </tbody>
			
        </table>
		<?= $pager->links() ?>



<a href="<?= base_url('logout') ?>" class="btn btn-danger">Logout</a>

    </div>

    <!-- Bootstrap JS (optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gW6c/9i9K3awr73b2nq8w3uEKDhmEjwsYS2gdSUuVXE1AplCqP+30JoPJFhRqtJf" crossorigin="anonymous"></script>
</body>
</html>
