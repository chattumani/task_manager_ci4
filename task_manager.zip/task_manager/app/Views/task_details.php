<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Custom CSS -->
    <link rel="stylesheet" href="/css/styles.css">
    <title>Task Details</title>
</head>
<body>
<div class="container mt-3">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1 class="text-center mb-4">Task Details</h1>

            <?php if ($task): ?>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Due Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?= $task['title'] ?></td>
                        <td><?= $task['description'] ?></td>
                        <td><?= $task['due_date'] ?></td>
                        <td><?= $task['status'] ?></td>
                    </tr>
                </tbody>
            </table>
            <?php else: ?>
            <p>Task not found.</p>
            <?php endif; ?>

            <a href="<?= base_url('tasks') ?>" class="btn btn-secondary mt-3">Back to Task List</a>
        </div>
    </div>
</div>



</body>
</html>
